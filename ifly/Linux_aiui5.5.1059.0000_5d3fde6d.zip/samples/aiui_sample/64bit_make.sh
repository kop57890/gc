make clean;make build "LINUX64=1"
export LD_LIBRARY_PATH=$(pwd)/../../libs/x64/
